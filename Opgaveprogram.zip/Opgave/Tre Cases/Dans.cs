﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tre_Cases
{
    internal class Dans
    {
        internal void Run()
        {
            string navn1, navn2, input1, input2;
            int point1, point2;


            Console.Clear();
            Console.WriteLine("Velkommen til Dans case");
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("Indtast navn på den første danser");
            navn1 = Console.ReadLine();
            Console.WriteLine("Indtast navn på den anden danser");
            navn2 = Console.ReadLine();
            Console.WriteLine("Indtast point for den første danser");
            input1 = Console.ReadLine();
            Console.WriteLine("Indtast point for den anden danser");
            input2 = Console.ReadLine();

            bool Stringproof1 = int.TryParse(input1, out point1);
            bool Stringproof2 = int.TryParse(input2, out point2);

            string Danser1 = navn1 + " " + point1;
            string Danser2 = navn2 + " " + point2;

           

            ClassLibrary1.Dans Dans_Objekt = new ClassLibrary1.Dans();
            string DansResultat = Dans_Objekt.DanserneOgDeresPoint(Danser1, Danser2);
            Console.WriteLine(DansResultat + (point1 + point2));

            Console.ReadKey();


        }
    }
}
