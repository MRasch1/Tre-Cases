﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tre_Cases
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string indtast, brugernavn_login, adgangskode_login;

            
            Console.WriteLine("Starten af programmet");
            Console.ReadKey();
            Console.WriteLine("Indtast brugernavn: ");
            brugernavn_login = Console.ReadLine().ToLower();
            Console.WriteLine("Indtast adgangskode: ");
            adgangskode_login = Console.ReadLine();



            ClassLibrary1.Program_login Program_login_Objekt = new ClassLibrary1.Program_login();
            string Program_loginResultat = Program_login_Objekt.LoginSåDuKanGåIndICases(brugernavn_login, adgangskode_login);
            Console.WriteLine(Program_loginResultat);
            Console.ReadKey();



            if (Program_loginResultat == "Login er godkendt")
            {


                do
                {


                    Console.Clear();
                    Console.WriteLine("Vælg en case");
                    Console.WriteLine("");
                    Console.WriteLine("Fodbold");
                    Console.WriteLine("");
                    Console.WriteLine("Dans");
                    Console.WriteLine("");
                    Console.WriteLine("Password");
                    Console.WriteLine("");
                    Console.WriteLine("Sluk");
                    Console.Write(": ");
                    indtast = Console.ReadLine().ToLower();

                    if (indtast == "fodbold")
                    {
                        var OpeningAfFodbold = new Fodbold();
                        OpeningAfFodbold.Run();
                    }

                    else if (indtast == "dans")
                    {
                        var OpeningAfDans = new Dans();
                        OpeningAfDans.Run();
                    }

                    else if (indtast == "password")
                    {
                        var OpeningAfPassword = new Password();
                        OpeningAfPassword.Run();
                    }

                } while (indtast != "sluk");
            }

            else
            {
                Console.WriteLine("Login mislykkedes. Nu lukker programmet");
                Console.ReadKey();
            }
        }
    }
}