﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tre_Cases
{
    internal class Password
    {
        internal void Run()
        {
            string brugernavn, kodeord;

             
                Console.Clear();
                Console.WriteLine("Velkommen til Password case");
                Console.ReadKey();
                Console.Clear();
                Console.WriteLine("Indtast brugernavn");
            brugernavn = Console.ReadLine().ToLower();
                Console.WriteLine("Indtast kodeord");
                kodeord = Console.ReadLine();



                ClassLibrary1.Password Password_Objekt = new ClassLibrary1.Password();
                string PasswordResultat = Password_Objekt.BrugernavnOgKodeord(brugernavn, kodeord);
                Console.WriteLine(PasswordResultat);

                Console.ReadKey();

            
        }
    }
}
