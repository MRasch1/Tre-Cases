﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Password
    {
        public string BrugernavnOgKodeord(string brugernavn, string kodeord)
        {
            var Login_Resultat = HvisGodkendt(brugernavn, kodeord);

            if (!string.IsNullOrEmpty(Login_Resultat))
            {
                return Login_Resultat;
            }
            else
            {
                return "Fejl indtast";
            }
        }

        private string HvisGodkendt(string brugernavn, string kodeord)
        {
                string MinFejlMeddelelse = "Kodeordet skal mindst være 12 tegn langt, der skal anvendes både store og små bogstaver, et tal mindst, benyttes mindst et specialtegn, tal må ikke være i starten og slutningen af koden, og der må ikke være mellemrum";
            

                bool ErDerMindstEtStortBogstav = kodeord.Any(char.IsUpper);
                bool ErDerMindstEtSmåtBogstav = kodeord.Any(char.IsLower);
                bool ErDerEtSpecialtegn = kodeord.Any(ch => !char.IsLetterOrDigit(ch));
                bool ErDerEtTalMindst = kodeord.Any(char.IsDigit);
                bool DerMåIkkeVæreTalIStarten = !string.IsNullOrEmpty(kodeord) && char.IsLetter(kodeord[0]);
                bool DerMåIkkeVæreTalISlutningen = !string.IsNullOrEmpty(kodeord) && char.IsLetter(kodeord.LastOrDefault());
                bool ErDerMellemrum = kodeord.Contains(" ");

                

                if (ErDerMindstEtStortBogstav == false || ErDerMindstEtSmåtBogstav == false || ErDerEtTalMindst == false || ErDerEtSpecialtegn == false || DerMåIkkeVæreTalIStarten == false || DerMåIkkeVæreTalIStarten == false || ErDerMellemrum == true)
                {
                    return MinFejlMeddelelse;
                }

                else
                {
                string brugerfil = @"C:\Users\magras\Desktop\Opgave\bruger.txt";
                string adgangskodefil = @"C:\Users\magras\Desktop\Opgave\adgangskode.txt";

                System.IO.File.WriteAllText(brugerfil, brugernavn);
                System.IO.File.WriteAllText(adgangskodefil, kodeord);

                return brugernavn + " " + kodeord;
                }

            
        }


    }
}
