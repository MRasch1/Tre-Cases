﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Fodbold
    {
        public string ErDerMålOgAfleveringer(string Mål, int Afleveringer)
        {
            var Resultat_string = HvisMål(Mål);

            if (!string.IsNullOrEmpty(Resultat_string))
            {
                return Resultat_string;
            }

            else
            {
                return HvisAflevering(Afleveringer);
            }
        }

        private string HvisMål(string Mål)
        {

            if (Mål == "mål")

            {
                return "Olé Olé Olé Olé";
            }

            return string.Empty;

        }

        private string HvisAflevering(int Afleveringer)
        {

            if (Afleveringer < 1)
            {
                return "shh";
            }
            else if (Afleveringer >= 1 && Afleveringer < 10)
            {
                var resultat = "";

                for (int i = 0; i < Afleveringer; i++)
                {
                    resultat += "Huh! ";
                }
                return resultat;
            }
            else 
                return "High Five - Jubel!!!";
        }
    }
}