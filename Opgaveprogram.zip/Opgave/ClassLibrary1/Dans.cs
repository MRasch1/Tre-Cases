﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Dans
    {
        public string DanserneOgDeresPoint(string Danser1, string Danser2)
        {
            var Danse_resultat = Dansere(Danser1, Danser2);

            if (!string.IsNullOrEmpty(Danse_resultat))
            { 
                return Danse_resultat;
            }
            else
            {
                return "Fejl indtast";
            }
        }

        private string Dansere(string Danser1, string Danser2)
        {
            return Danser1 + " " + "&" + " " + Danser2 + ". " + "Deres samlede point: " ;
        }
    }
}
