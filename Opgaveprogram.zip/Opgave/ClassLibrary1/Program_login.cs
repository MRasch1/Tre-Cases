﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Program_login
    {
        public string LoginSåDuKanGåIndICases(string brugernavn_login, string adgangskode_login)
        {
            var Login_Resultat = HvisLogin(brugernavn_login, adgangskode_login);

            if (!string.IsNullOrEmpty(Login_Resultat))
            {
                return Login_Resultat;
            }
            else
            {
                return "Fejl indtast";
            }
        }

        private string HvisLogin(string brugernavn_login, string adgangskode_login)
        {
            string bruger = System.IO.File.ReadAllText(@"C:\Users\magras\Desktop\Opgave\bruger.txt");
            string adgangskode = System.IO.File.ReadAllText(@"C:\Users\magras\Desktop\Opgave\adgangskode.txt");

            if (bruger == brugernavn_login && adgangskode == adgangskode_login)
            {
                return "Login er godkendt";
            }

            else
            {
                return "Forkert brugernavn eller kode";
            }

            
            

            

        }
    }
}
